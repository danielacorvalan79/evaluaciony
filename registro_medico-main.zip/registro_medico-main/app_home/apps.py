from django.apps import AppConfig


class ApphomeConfig(AppConfig):
    name = 'appHome'
