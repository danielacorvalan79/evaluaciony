from django.apps import AppConfig


class AppadminConfig(AppConfig):
    name = 'app_admin'
