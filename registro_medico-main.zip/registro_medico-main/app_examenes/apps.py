from django.apps import AppConfig


class AppExamenesConfig(AppConfig):
    name = 'app_examenes'
