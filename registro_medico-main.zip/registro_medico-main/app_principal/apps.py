from django.apps import AppConfig


class AppPrincipalConfig(AppConfig):
    name = 'app_principal'
