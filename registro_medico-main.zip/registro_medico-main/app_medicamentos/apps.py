from django.apps import AppConfig


class AppMedicamentosConfig(AppConfig):
    name = 'app_medicamentos'
